/**
 * Created by Roman Spiridonov <romars@phystech.edu> on ${DATE}.
 */
define(function() {
    return {};
});